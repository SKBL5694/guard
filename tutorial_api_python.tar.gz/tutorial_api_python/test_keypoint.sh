#!/bin/bash

dcount=0
while read img_dir json_dir
do
	if [ -d $img_dir ];then
		if [ ! -d $json_dir ];then
			mkdir -p $json_dir

		fi

		python3 test_custom_keypoints.py --image_dir $img_dir --no_display True --write_json $json_dir
		dcount=$((dcount+1))
		echo "Process No: $dcount." >> keypoints_new.log
	fi

done<$1


